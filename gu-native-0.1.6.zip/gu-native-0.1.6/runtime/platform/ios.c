// iOS host layer for MHGU Recomp. POSIX/Darwin implementation for ARM64.
// Write tracking is intentionally disabled, as in the Linux backend.
#define _DARWIN_C_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <execinfo.h>
#include <limits.h>
#include <mach/mach_time.h>
#include <signal.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/ucontext.h>
#include <time.h>
#include <unistd.h>
#include <mach-o/dyld.h>

#include "../platform.h"

#define COMMIT_CHUNK 0x10000ull
#define MAX_GUEST_SIZE 0x100000000ull
#define MAX_CHUNKS ((MAX_GUEST_SIZE + COMMIT_CHUNK - 1) / COMMIT_CHUNK)

enum { CHUNK_FREE = 0, CHUNK_BUSY, CHUNK_READY };
static uint64_t g_lo, g_hi;
static _Atomic unsigned char g_chunk[MAX_CHUNKS];
void (*plat_touch_hook)(uint64_t guest_addr, int write);

static bool chunk_back(uint64_t base) {
    void *p = mmap((void *)(uintptr_t)base, COMMIT_CHUNK, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANON | MAP_FIXED, -1, 0);
    return p == (void *)(uintptr_t)base;
}

static bool lazy_commit(uint64_t addr) {
    if (addr < g_lo || addr >= g_hi) return false;
    uint64_t idx = (addr - g_lo) / COMMIT_CHUNK;
    if (idx >= MAX_CHUNKS) return false;
    unsigned char expected = CHUNK_FREE;
    if (atomic_compare_exchange_strong(&g_chunk[idx], &expected, CHUNK_BUSY)) {
        bool ok = chunk_back(g_lo + idx * COMMIT_CHUNK);
        atomic_store(&g_chunk[idx], ok ? CHUNK_READY : CHUNK_FREE);
        return ok;
    }
    while (atomic_load(&g_chunk[idx]) == CHUNK_BUSY) atomic_thread_fence(memory_order_acquire);
    return atomic_load(&g_chunk[idx]) == CHUNK_READY;
}

static void fault_handler(int sig, siginfo_t *si, void *opaque);

bool plat_reserve_guest(uint64_t base, uint64_t size) {
    if (!size || size > MAX_GUEST_SIZE || (base & (PLAT_PAGE - 1)) || (size & (PLAT_PAGE - 1))) return false;
    // Do not use MAP_FIXED for the initial reservation: never overwrite another mapping.
    void *p = mmap((void *)(uintptr_t)base, (size_t)size, PROT_NONE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (p == MAP_FAILED) return false;
    if (p != (void *)(uintptr_t)base) { munmap(p, (size_t)size); return false; }
    g_lo = base;
    g_hi = base + size;
    struct sigaction sa = {0};
    sa.sa_sigaction = fault_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    if (sigaction(SIGSEGV, &sa, NULL) != 0 || sigaction(SIGBUS, &sa, NULL) != 0) {
        munmap((void *)(uintptr_t)base, (size_t)size);
        g_lo = g_hi = 0;
        return false;
    }
    return true;
}

void plat_commit(uint64_t addr, uint64_t size) {
    if (!size || !g_lo || addr >= g_hi || addr + size <= g_lo) return;
    uint64_t start = addr & ~(COMMIT_CHUNK - 1);
    uint64_t end = (addr + size + COMMIT_CHUNK - 1) & ~(COMMIT_CHUNK - 1);
    if (end < addr || end > g_hi) end = g_hi;
    for (uint64_t p = start < g_lo ? g_lo : start; p < end; p += COMMIT_CHUNK) {
        if (!lazy_commit(p)) fprintf(stderr, "[ios] failed to commit guest chunk at %llx\n", (unsigned long long)p);
    }
}

int plat_written_pages(uint64_t addr, uint64_t size, uint64_t *pages, int max, uint64_t *page) {
    (void)addr; (void)size; (void)pages; (void)max; (void)page;
    return -1;
}

bool plat_committed(uint64_t addr, uint64_t *end) {
    if (!g_lo || addr < g_lo || addr >= g_hi) { *end = addr + PLAT_PAGE; return false; }
    uint64_t idx = (addr - g_lo) / COMMIT_CHUNK;
    if (idx >= MAX_CHUNKS || atomic_load(&g_chunk[idx]) != CHUNK_READY) {
        *end = g_lo + (idx + 1) * COMMIT_CHUNK;
        return false;
    }
    uint64_t n = idx;
    while (n + 1 < MAX_CHUNKS && n - idx < 4096 && atomic_load(&g_chunk[n + 1]) == CHUNK_READY) n++;
    *end = g_lo + (n + 1) * COMMIT_CHUNK;
    if (*end > g_hi) *end = g_hi;
    return true;
}

int plat_protect(uint64_t addr, uint64_t size, int prot) {
    int native_prot = prot == PLAT_PROT_NONE ? PROT_NONE : prot == PLAT_PROT_READ ? PROT_READ : PROT_READ | PROT_WRITE;
    if (addr >= g_lo && addr < g_hi) plat_commit(addr, size);
    return mprotect((void *)(uintptr_t)addr, (size_t)size, native_prot) == 0 ? 0 : -1;
}

uint64_t plat_now_ns(void) {
    static mach_timebase_info_data_t tb;
    if (!tb.denom) mach_timebase_info(&tb);
    return (uint64_t)(((__uint128_t)mach_absolute_time() * tb.numer) / tb.denom);
}

void plat_sleep_until_ns(uint64_t target) {
    for (;;) {
        uint64_t now = plat_now_ns();
        if (now >= target) return;
        uint64_t left = target - now;
        if (left > 300000) {
            struct timespec req = { (time_t)((left - 200000) / 1000000000ull),
                                    (long)((left - 200000) % 1000000000ull) };
            nanosleep(&req, NULL);
        } else {
            // Short final interval: yield rather than spin aggressively on a mobile device.
            sched_yield();
        }
    }
}

void plat_init(void) { signal(SIGPIPE, SIG_IGN); }
unsigned long plat_process_id(void) { return (unsigned long)getpid(); }
bool plat_wait_process(unsigned long pid) {
    struct timespec pause = {0, 10000000};
    for (int i = 0; i < 3000; ++i) {
        if (kill((pid_t)pid, 0) < 0) return errno == ESRCH;
        nanosleep(&pause, NULL);
    }
    return false;
}

bool plat_exe_path(char *buf, size_t size) {
    if (!buf || size < 2) return false;
    uint32_t n = (uint32_t)size;
    if (_NSGetExecutablePath(buf, &n) != 0) return false;
    char resolved[PATH_MAX];
    if (realpath(buf, resolved)) {
        if (strlen(resolved) >= size) return false;
        snprintf(buf, size, "%s", resolved);
    }
    return true;
}

void plat_standalone(void) {
    // iOS runs inside an application sandbox; the bundle is read-only. Keep the current working directory unchanged.
    if (!isatty(STDERR_FILENO)) setvbuf(stderr, NULL, _IONBF, 0);
}

static bool mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    if (strlen(path) >= sizeof tmp) return false;
    snprintf(tmp, sizeof tmp, "%s", path);
    for (char *p = tmp + 1; *p; ++p) {
        if (*p != '/') continue;
        *p = 0;
        if (mkdir(tmp, 0755) != 0 && errno != EEXIST) return false;
        *p = '/';
    }
    return mkdir(tmp, 0755) == 0 || errno == EEXIST;
}

bool plat_user_dir(char *buf, size_t size) {
    const char *home = getenv("HOME");
    if (!home || !*home || !buf || !size) return false;
    char dir[PATH_MAX];
    int n = snprintf(dir, sizeof dir, "%s/Documents/MHGURecomp", home);
    if (n < 0 || (size_t)n >= sizeof dir || strlen(dir) >= size) return false;
    if (!mkdir_p(dir)) return false;
    struct stat st;
    if (stat(dir, &st) != 0 || !S_ISDIR(st.st_mode)) return false;
    snprintf(buf, size, "%s", dir);
    return true;
}

static int count_files(const char *dir, int depth) {
    if (depth > 32) return 0;
    DIR *d = opendir(dir);
    if (!d) return 0;
    int count = 0;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (e->d_name[0] == '.') continue;
        char path[PATH_MAX];
        int n = snprintf(path, sizeof path, "%s/%s", dir, e->d_name);
        if (n < 0 || (size_t)n >= sizeof path) continue;
        struct stat st;
        if (stat(path, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) count += count_files(path, depth + 1);
        else if (S_ISREG(st.st_mode)) count++;
    }
    closedir(d);
    return count;
}
int plat_count_files(const char *dir) { return count_files(dir, 0); }

void plat_error_box(const char *msg) { fprintf(stderr, "\n*** MHGU Recomp: %s\n", msg ? msg : "unknown error"); }
void plat_fatal_notice(void) { fprintf(stderr, "[ios] fatal error; see the application log.\n"); }

const char *plat_symbol(uint64_t pc, uint64_t *offset) {
    static __thread char name[PATH_MAX];
    Dl_info info;
    if (!dladdr((void *)(uintptr_t)pc, &info) || !info.dli_fname) return NULL;
    const char *slash = strrchr(info.dli_fname, '/');
    snprintf(name, sizeof name, "%s", slash ? slash + 1 : info.dli_fname);
    if (offset) *offset = pc - (uint64_t)(uintptr_t)info.dli_fbase;
    return name;
}

const char *rt_host_fn_name(uint64_t pc, uint64_t *offset);
void plat_print_backtrace(void) {
    void *frames[64];
    int n = backtrace(frames, 64);
    for (int i = 0; i < n; ++i) {
        uint64_t pc = (uint64_t)(uintptr_t)frames[i], off = 0;
        const char *name = rt_host_fn_name(pc, &off);
        if (!name) name = plat_symbol(pc, &off);
        if (name) fprintf(stderr, "  #%02d %016llx %s+%llx\n", i, (unsigned long long)pc, name, (unsigned long long)off);
        else fprintf(stderr, "  #%02d %016llx\n", i, (unsigned long long)pc);
    }
}

static const char *signal_name(int sig) {
    switch (sig) {
    case SIGSEGV: return "SIGSEGV";
    case SIGBUS: return "SIGBUS";
    case SIGFPE: return "SIGFPE";
    case SIGILL: return "SIGILL";
    default: return "signal";
    }
}

static void fault_handler(int sig, siginfo_t *si, void *opaque) {
    ucontext_t *ctx = (ucontext_t *)opaque;
    uint64_t fault = si && si->si_addr ? (uint64_t)(uintptr_t)si->si_addr : 0;
    if ((sig == SIGSEGV || sig == SIGBUS) && lazy_commit(fault)) {
        // Darwin ARM64 does not expose Linux's REG_ERR bit. The access type is left unknown.
        if (plat_touch_hook) plat_touch_hook(fault - g_lo, -1);
        return;
    }
    uint64_t pc = 0, sp = 0, lr = 0, end = 0;
#if defined(__arm64__)
    if (ctx && ctx->uc_mcontext) {
        pc = ctx->uc_mcontext->__ss.__pc;
        sp = ctx->uc_mcontext->__ss.__sp;
        lr = ctx->uc_mcontext->__ss.__lr;
    }
#endif
    if (!lr && plat_committed(sp, &end) && end - sp >= sizeof(uint64_t)) lr = *(const uint64_t *)(uintptr_t)sp;
    char what[96];
    snprintf(what, sizeof what, "%s (code %d, addr %llx)", signal_name(sig), si ? si->si_code : 0,
             (unsigned long long)fault);
    rt_fault_report(what, fault, pc, lr);
    _exit(128 + sig);
}

void plat_crash_handler_install(void) {
    static char altstack[256 * 1024] __attribute__((aligned(16)));
    stack_t ss = {.ss_sp = altstack, .ss_size = sizeof altstack};
    sigaltstack(&ss, NULL);
    struct sigaction sa = {0};
    sa.sa_sigaction = fault_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigaction(SIGFPE, &sa, NULL);
    sigaction(SIGILL, &sa, NULL);
}
